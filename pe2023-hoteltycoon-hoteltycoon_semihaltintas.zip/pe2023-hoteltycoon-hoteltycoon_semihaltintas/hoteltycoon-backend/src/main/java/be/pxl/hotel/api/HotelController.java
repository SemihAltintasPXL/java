package be.pxl.hotel.api;

import be.pxl.hotel.api.request.CreateHotelRequest;
import be.pxl.hotel.api.response.HotelDTO;
import be.pxl.hotel.api.response.HotelDetailDTO;
import be.pxl.hotel.domain.Facility;
import be.pxl.hotel.service.HotelService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.crossstore.ChangeSetPersister;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/hotels")
public class HotelController {
    @Autowired
    private HotelService hotelService;

    @GetMapping
    public ResponseEntity<List<HotelDTO>> getAllHotels() {
        return ResponseEntity.ok(hotelService.getHotels());
    }
    @PostMapping("/{hotelId}")
    public ResponseEntity<HotelDetailDTO> createHotel(@PathVariable Long hotelId){
        return ResponseEntity.ok(hotelService.createHotelById(hotelId));
    }
    @PostMapping
    public ResponseEntity<Void> createHotel(@RequestBody CreateHotelRequest createHotelRequest) throws ChangeSetPersister.NotFoundException {
        hotelService.createHotel(createHotelRequest);
        return ResponseEntity.status(201).build();
    }
    @PostMapping("/{hotelId}/buy-building")
    public ResponseEntity<Void> buyBuilding(@PathVariable Long hotelId){
        hotelService.buyBuilding(hotelId);
        return ResponseEntity.status(201).build();
    }
    @PostMapping("/{hotelId}/buy-facility/{facility}")
    public ResponseEntity<Void> buyFacility(@PathVariable Long hotelId, @PathVariable Facility facility) {
        hotelService.buyFacility(hotelId,facility);
        return ResponseEntity.status(201).build();
    }
}
