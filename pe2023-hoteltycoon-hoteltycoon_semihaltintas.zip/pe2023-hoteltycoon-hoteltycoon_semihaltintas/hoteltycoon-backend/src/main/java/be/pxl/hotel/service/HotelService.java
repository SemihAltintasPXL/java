package be.pxl.hotel.service;

import be.pxl.hotel.api.request.CreateHotelRequest;
import be.pxl.hotel.api.response.*;
import be.pxl.hotel.domain.*;
import be.pxl.hotel.exception.InvalidRequestException;
import be.pxl.hotel.exception.NotFoundException;
import be.pxl.hotel.repository.BankRepository;
import be.pxl.hotel.repository.BuildingPlotRepository;
import be.pxl.hotel.repository.HotelRepository;
import org.apache.commons.lang3.NotImplementedException;
import org.aspectj.weaver.ast.Not;
import org.springframework.data.crossstore.ChangeSetPersister;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class HotelService {

	private HotelRepository hotelRepository;
	private BuildingPlotRepository buildingPlotRepository;
	private BankRepository bankRepository;

	public HotelService(HotelRepository hotelRepository, BuildingPlotRepository buildingPlotRepository, BankRepository bankRepository) {
		this.hotelRepository = hotelRepository;
		this.buildingPlotRepository = buildingPlotRepository;
		this.bankRepository = bankRepository;
	}
	public Wallet getWallet() {
		return bankRepository.findAll().get(0);
	}
	public List<HotelDTO> getHotels() {
		return hotelRepository.findAll().stream().map(hotel -> {
			HotelDTO hotelDTO = new HotelDTO(hotel.getId(), hotel.getName(), hotel.getStars());
			return hotelDTO;
		}).collect(Collectors.toList());
	}
	public HotelDetailDTO createHotelById (long id) {
		return hotelRepository.findById(id).map(hotel -> {
			HotelDetailDTO hotelDetailDTO = new HotelDetailDTO();
			hotelDetailDTO.setId(hotel.getId());
			hotelDetailDTO.setName(hotel.getName());
			hotelDetailDTO.setStarRating(hotel.getStars());
			hotelDetailDTO.setMaxBuildings(hotel.getBuildingPlot().getMaxBuildings());
			//PRICELIST
			HotelPriceDTO hotelPriceDTO = new HotelPriceDTO();
			hotelPriceDTO.setPriceAdditionalBuilding(hotel.getPriceAdditionalBuilding());
			hotelPriceDTO.setPricePerNight(hotel.getPricePerNight());
			hotelPriceDTO.setPriceMainBuilding(hotel.getPriceMainBuilding());
			hotelDetailDTO.setPricelist(hotelPriceDTO);
			//BUILDINGS
			List<HotelBuildingDTO> hotelBuildingDTOS = new ArrayList<>();
			for (Building building : hotel.getBuildings()) {
				HotelBuildingDTO hotelBuildingDTO = new HotelBuildingDTO();
				hotelBuildingDTO.setName(building.getName());
				hotelBuildingDTO.setPrice(building.getPrice());
				hotelBuildingDTOS.add(hotelBuildingDTO);
			}
			hotelDetailDTO.setBuildings(hotelBuildingDTOS);
			//FACILITIES
			List<HotelFacilityDTO> hotelFacilityDTOS = new ArrayList<>();
			for (Facility facility : hotel.facilities) {
				HotelFacilityDTO hotelFacilityDTO = new HotelFacilityDTO();
				hotelFacilityDTO.setName(facility);
				hotelFacilityDTO.setPrice(facility.getPrice());
				hotelFacilityDTO.setAvailable(hotel.hasFacility(facility));
				hotelFacilityDTOS.add(hotelFacilityDTO);
			}
			hotelDetailDTO.setFacilities(hotelFacilityDTOS);
			return hotelDetailDTO;
		}).orElse(null);
	}
	public void createHotel(CreateHotelRequest createHotelRequest){
		Hotel hotel = new Hotel(createHotelRequest.name());
		BuildingPlot buildingPlot = buildingPlotRepository.findById(createHotelRequest.buildingplotId()).orElse(null);
		if (buildingPlot == null) {
			throw new NotFoundException("Building plot not found");
		}
		hotel.setBuildingPlot(buildingPlot);
		Hotel foundHotel = hotelRepository.findByBuildingPlot_Id(createHotelRequest.buildingplotId());
		if (foundHotel != null) {
			throw new InvalidRequestException("Hotel already exists for this building plot");
		}
		hotelRepository.save(hotel);
		buildingPlotRepository.save(buildingPlot);
	}
	public void buyBuilding(long hotelId) {
		Hotel hotel = hotelRepository.findById(hotelId).orElse(null);
		if (hotel == null) {
			throw new NotFoundException("Hotel not found");
		}
		hotel.addBuilding(getWallet());
		bankRepository.save(getWallet());
		hotelRepository.save(hotel);
	}

	public void buyFacility(long hotelId, Facility facility) {
		Hotel hotel = hotelRepository.findById(hotelId).orElse(null);
		if (hotel == null) {
			throw new NotFoundException("Hotel not found");
		}
		hotel.addFacility(facility, getWallet());
		bankRepository.save(getWallet());
		hotelRepository.save(hotel);
	}

	public List<Hotel> findAllOpenHotels() {
		return hotelRepository.findAll().stream().toList();
	}

	public void book(Hotel hotel, int persons, int nights) {
		// TODO: book the given hotel for the given number of persons for the given number of nights
		// make sure you receive the money on your wallet!
		hotel.book(persons, nights, getWallet());
		bankRepository.save(getWallet());
	}
}
