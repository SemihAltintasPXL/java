package be.pxl.hotel;

import be.pxl.hotel.domain.BuildingPlot;
import be.pxl.hotel.repository.BuildingPlotRepository;
import be.pxl.hotel.service.BuildingPlotService;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

import java.util.Arrays;
import java.util.List;

@SpringBootApplication
public class HoteltycoonBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(HoteltycoonBackendApplication.class, args);

	}

}
