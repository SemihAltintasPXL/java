package be.pxl.hotel.domain;

import jakarta.persistence.*;

import java.time.LocalDateTime;

@Entity
public class Building {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private double price;
    private String name;
    @ManyToOne
    private Hotel hotel;
    private LocalDateTime constructionDate;

    public Building(double price, String name, Hotel hotel) {
        this.price = price;
        this.name = name;
        this.hotel = hotel;
    }

    public Building() {
    	// JPA Only
    }

    public Long getId() {
        return id;
    }

    public double getPrice() {
        return price;
    }

    public String getName() {
        return name;
    }

    public Hotel getHotel() {
        return hotel;
    }

    public LocalDateTime getConstructionDate() {
        return constructionDate;
    }
    public void setName(String name) {
        this.name = name;
    }
}
