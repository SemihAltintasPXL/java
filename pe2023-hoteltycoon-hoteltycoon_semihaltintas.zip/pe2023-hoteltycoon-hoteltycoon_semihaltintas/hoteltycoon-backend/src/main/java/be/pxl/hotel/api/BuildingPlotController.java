package be.pxl.hotel.api;

import be.pxl.hotel.api.response.BuildingPlotDTO;
import be.pxl.hotel.service.BuildingPlotService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/buildingplots")
public class BuildingPlotController {

    @Autowired
    private BuildingPlotService buildingPlotService;


    @GetMapping
    public ResponseEntity<List<BuildingPlotDTO>> getBuildingPlotNotSold() {
        return ResponseEntity.ok(buildingPlotService.getBuildingPlotNotSold());
    }
    @PostMapping("/{buildingplotId}/buy")
    public ResponseEntity<Void> buyBuildingPlot(@PathVariable long buildingplotId) {
        buildingPlotService.buyBuildingPlot(buildingplotId);
        return ResponseEntity.ok().build();
    }
}
