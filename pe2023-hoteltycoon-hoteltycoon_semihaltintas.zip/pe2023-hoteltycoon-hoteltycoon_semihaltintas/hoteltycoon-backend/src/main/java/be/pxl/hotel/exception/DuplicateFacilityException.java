package be.pxl.hotel.exception;

public class DuplicateFacilityException extends RuntimeException{

        public DuplicateFacilityException(String message) {
            super(message);
        }
}
