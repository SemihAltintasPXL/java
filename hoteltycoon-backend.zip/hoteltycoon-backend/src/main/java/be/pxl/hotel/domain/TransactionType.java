package be.pxl.hotel.domain;

public enum TransactionType {
	PAYMENT,
	RECEIPT

}
