package be.pxl.hotel.exception;

public class ConstructionViolationException extends RuntimeException{

    public ConstructionViolationException(String message) {
        super(message);
    }

}
