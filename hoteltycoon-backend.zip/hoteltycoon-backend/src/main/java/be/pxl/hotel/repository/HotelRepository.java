package be.pxl.hotel.repository;

import be.pxl.hotel.domain.Hotel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface HotelRepository extends JpaRepository<Hotel, Long> {
    Hotel findByBuildingPlot_Id(long id);
}
