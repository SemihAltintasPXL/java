package be.pxl.hotel.domain;

import be.pxl.hotel.exception.ConstructionViolationException;
import be.pxl.hotel.exception.DuplicateFacilityException;
import be.pxl.hotel.exception.InvalidBookingException;
import jakarta.persistence.*;

import java.util.ArrayList;
import java.util.List;

@Entity
public class Hotel {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @OneToOne
    private BuildingPlot buildingPlot;
    private String name;

    public List<Facility> facilities;

    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    private List<Building> buildings;

    private boolean mainBuildingAdded;

    public Hotel(String name) {
        this.name = name;
        this.facilities = new ArrayList<>();
        this.buildings = new ArrayList<>();
        this.mainBuildingAdded = false;
    }

    public Hotel() {
        // JPA Only
    }

    public Long getId() {
        return id;
    }

    public int getNumberOfBuildings() {
        return buildings.size();
    }

    public void addFacility(Facility facility) {
        if (facilities.contains(facility)) {
            throw new DuplicateFacilityException("Facility already added to the hotel");
        }
        facilities.add(facility);
    }

    public double getPriceMainBuilding() {
        return 1.5 * buildingPlot.getPrice();
    }

    public double getPriceAdditionalBuilding() {
        return 1.1 * buildingPlot.getPrice();
    }

    public void addBuilding(Wallet wallet) throws ConstructionViolationException {
        if (mainBuildingAdded) {
            if (buildings.size() >= buildingPlot.getMaxBuildings()) {
                throw new ConstructionViolationException("Cannot add more buildings to the hotel");
            }

            if (wallet.getAmount() < getPriceAdditionalBuilding()) {
                throw new ConstructionViolationException("Not enough money to add the building");
            }

            buildings.add(new Building(getPriceAdditionalBuilding(), "Building " + buildings.size(), this));
            wallet.registerPayment(getPriceAdditionalBuilding(), "Building " + buildings.size());
        } else {
            if (wallet.getAmount() < getPriceMainBuilding()) {
                throw new ConstructionViolationException("Not enough money to add the main building");
            }

            buildings.add(new Building(getPriceMainBuilding(), "Main building", this));
            wallet.registerPayment(getPriceMainBuilding() , "Main building");
            mainBuildingAdded = true;
        }
    }

    public boolean isOpen() {
        return mainBuildingAdded;
    }

    public void addFacility(Facility facility, Wallet wallet) throws ConstructionViolationException {
        if (!mainBuildingAdded) {
            throw new ConstructionViolationException("Cannot add facility without main building");
        }

        if (hasFacility(facility)) {
            throw new DuplicateFacilityException("Facility already added to the hotel");
        }

        if (wallet.getAmount() < facility.getPrice()) {
            throw new ConstructionViolationException("Not enough money to add the facility");
        }

        facilities.add(facility);
        wallet.registerPayment(facility.getPrice(), "Facility is added to the hotel");
    }

    public boolean hasFacility(Facility facility) {
        return facilities.contains(facility);
    }

    public int getStars() {
        return Math.min(5, buildings.size() + facilities.size());
    }

    public double getPricePerNight() {
        double basePricePerPerson = buildingPlot.getPrice() / 400.0;
        double starSurchargePerStar = basePricePerPerson / 3.0;

        int stars = getStars();
        double totalPrice = basePricePerPerson;

        if (stars > 1) {
            totalPrice += (stars - 1) * starSurchargePerStar;
        }

        return totalPrice;
    }

    public String getName() {
        return name;
    }

    public void book(int numberOfPersons, int numberOfNights, Wallet wallet) throws InvalidBookingException {
        if (!isOpen()) {
            throw new InvalidBookingException("Hotel is not open for guests");
        }

        double totalPrice = numberOfPersons * numberOfNights * getPricePerNight();
        if (wallet.getAmount() < totalPrice) {
            throw new InvalidBookingException("Not enough money to book the hotel");
        }


        wallet.registerReceipt(totalPrice, "Booking " + numberOfPersons + " persons for " + numberOfNights + " nights" );
        wallet.registerPayment(totalPrice, "Booking " + numberOfPersons + " persons for " + numberOfNights + " nights" );
    }
    public double getTotalCost() {
        double totalCost = 0;
        for (Building building : buildings) {
            totalCost += building.getPrice();
        }
        return totalCost;
    }
    public List<Building> getBuildings() {
        return buildings;
    }
    public BuildingPlot getBuildingPlot() {
        return buildingPlot;
    }
    public void setBuildingPlot(BuildingPlot buildingPlot) {
        this.buildingPlot = buildingPlot;
    }
    public double getPriceFacilities() {
        double totalCost = 0;
        for (Facility facility : facilities) {
            totalCost += facility.getPrice();
        }
        return totalCost;
    }
}
