package be.pxl.hotel.service;

import be.pxl.hotel.api.response.BuildingPlotDTO;
import be.pxl.hotel.domain.BuildingPlot;
import be.pxl.hotel.domain.Wallet;
import be.pxl.hotel.exception.UnsufficientMoneyException;
import be.pxl.hotel.repository.BankRepository;
import be.pxl.hotel.repository.BuildingPlotRepository;
import jakarta.annotation.PostConstruct;
import jakarta.transaction.Transactional;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.List;

@Service
public class BuildingPlotService {
        private BuildingPlotRepository buildingPlotRepository;
        private BankRepository bankRepository;

        public BuildingPlotService(BuildingPlotRepository buildingPlotRepository, BankRepository bankRepository) {
            this.buildingPlotRepository = buildingPlotRepository;
            this.bankRepository = bankRepository;
        }

        @PostConstruct
        public void init() {
            saveBuildingPlot(7000, 4);
            saveBuildingPlot(10000, 3);
            saveBuildingPlot(10500, 1);
            saveBuildingPlot(13500, 4);
        }

        private void saveBuildingPlot(double price, int maxBuildings) {
            BuildingPlot plot = new BuildingPlot(price, maxBuildings);
            buildingPlotRepository.save(plot);
        }
        public List<BuildingPlotDTO> getBuildingPlotNotSold() {
            return buildingPlotRepository.findBySold(false);
        }
        @Transactional
        public ResponseEntity<String> buyBuildingPlot(long id) {
            BuildingPlot plot = buildingPlotRepository.findById(id).orElseThrow();
            Wallet wallet = bankRepository.findAll().get(0);
            double plotPrice = plot.getPrice();

            if (plot.isSold()) {
                return new ResponseEntity<>("The building plot is already sold.", HttpStatus.BAD_REQUEST);
            }
            else if (wallet.getAmount() < plotPrice) {
                throw new UnsufficientMoneyException("You don't have enough money to buy this building plot.");
            }
            wallet.registerPayment(plotPrice, "Buying building plot");
            bankRepository.save(wallet);
            plot.setSold(true);
            buildingPlotRepository.save(plot);
            return new ResponseEntity<>("You have successfully bought the building plot.", HttpStatus.OK);
        }
}
