package be.pxl.hotel.api;

import be.pxl.hotel.api.request.CreateTransactionRequest;
import be.pxl.hotel.api.response.TransactionsOverviewDTO;
import be.pxl.hotel.exception.UnsufficientMoneyException;
import be.pxl.hotel.service.BankService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/wallet")
public class BankController {

    @Autowired
    private BankService bankService;

    @GetMapping
    public ResponseEntity<Double> getAmmountOfCurrentWallet() {
        return new ResponseEntity<>(bankService.getAmountOfTheCurrentWallet(), HttpStatus.OK);
    }
    @PostMapping("/transactions")
    public ResponseEntity<String> createTransaction(@RequestBody CreateTransactionRequest createTransactionRequest){
        if (createTransactionRequest == null || createTransactionRequest.getAmount() <= 0) {
            return new ResponseEntity<>("Invalid data", HttpStatus.BAD_REQUEST);
        }
        try {
            bankService.createTransaction(createTransactionRequest);
        } catch (UnsufficientMoneyException e) {
            return new ResponseEntity<>("Insufficient funds", HttpStatus.PAYMENT_REQUIRED);
        }
        return new ResponseEntity<>("Transaction created", HttpStatus.CREATED);
    }
    @GetMapping("/transactions")
    public ResponseEntity<TransactionsOverviewDTO> overviewTransactions() {
        return new ResponseEntity<>(bankService.overvieuwTransactions(), HttpStatus.OK);
    }
}
