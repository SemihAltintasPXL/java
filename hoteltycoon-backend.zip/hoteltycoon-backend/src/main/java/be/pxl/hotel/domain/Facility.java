package be.pxl.hotel.domain;


public enum Facility {
    SWIMMING_POOL(10.0),
    FITNESS(15.0),
    SAUNA(12.5),
    TENNIS_COURT(8.0),
    SPA(20.0),
    RESTAURANT(25.0);

    private double price;

    Facility(double price) {
        this.price = price;
    }

    public double getPrice() {
        return price;
    }
}
