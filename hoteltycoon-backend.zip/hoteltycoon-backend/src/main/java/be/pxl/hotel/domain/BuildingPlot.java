package be.pxl.hotel.domain;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class BuildingPlot {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private double price;
    private int maxBuildings;
    private boolean sold;


    public BuildingPlot(double price, int maxBuildings) {
        this.price = price;
        this.maxBuildings = maxBuildings;
        this.sold = false;
    }

    public BuildingPlot() {
        // JPA Only
    }

    public Integer getId() {
        return id;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getMaxBuildings() {
        return maxBuildings;
    }

    public void setMaxBuildings(int maxBuildings) {
        this.maxBuildings = maxBuildings;
    }

    public boolean isSold() {
        return sold;
    }

    public void setSold(boolean sold) {
        this.sold = sold;
    }
}
