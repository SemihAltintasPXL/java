package be.pxl.hotel.exception;

public class InvalidBookingException extends RuntimeException{

        public InvalidBookingException(String message) {
            super(message);
        }
}
