package be.pxl.hotel.service;

import be.pxl.hotel.api.request.CreateTransactionRequest;
import be.pxl.hotel.api.response.TransactionsOverviewDTO;
import be.pxl.hotel.domain.Transaction;
import be.pxl.hotel.domain.TransactionType;
import be.pxl.hotel.domain.Wallet;
import be.pxl.hotel.exception.UnsufficientMoneyException;
import be.pxl.hotel.repository.BankRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.List;
import java.util.Properties;
import java.util.stream.Collectors;

@Service
public class BankService {
    private final BankRepository bankRepository;
    private Properties properties;
    private Wallet wallet;
    public BankService(BankRepository bankRepository) throws IOException {
        this.bankRepository = bankRepository;
        properties = new Properties();
        properties.load(getClass().getClassLoader().getResourceAsStream("application.properties"));
        double initialAmount = Double.parseDouble(properties.getProperty("wallet.initial-amount"));
        wallet = new Wallet(initialAmount);
        bankRepository.save(wallet);
    }
    public double getAmountOfTheCurrentWallet() {
        wallet = bankRepository.findAll().get(0);
        return wallet.getAmount();
    }

    public void createTransaction(CreateTransactionRequest createTransactionRequest){
        wallet = bankRepository.findAll().get(0);
        wallet.registerPayment(createTransactionRequest.getAmount(), createTransactionRequest.getDescription());
        bankRepository.save(wallet);
    }
    public TransactionsOverviewDTO overvieuwTransactions() {
        List<Transaction> transactions = wallet.getTransactions();

        List<Transaction> payments = transactions.stream()
                .filter(t -> t.getTransactionType() == TransactionType.PAYMENT)
                .toList();

        List<Transaction> receipts = transactions.stream()
                .filter(t -> t.getTransactionType() == TransactionType.RECEIPT)
                .toList();

        double totalPayments = payments.stream().mapToDouble(Transaction::getAmount).sum();
        double averagePayments = payments.stream().mapToDouble(Transaction::getAmount).average().orElse(0.0);

        double totalReceipts = receipts.stream().mapToDouble(Transaction::getAmount).sum();
        double averageReceipts = receipts.stream().mapToDouble(Transaction::getAmount).average().orElse(0.0);
        return new TransactionsOverviewDTO(payments, receipts, totalPayments, averagePayments, totalReceipts, averageReceipts);
    }

}
