export interface Pricelist {
  priceMainBuilding: number;
  priceAdditionalBuilding: number;
  pricePerNight: number;
}
