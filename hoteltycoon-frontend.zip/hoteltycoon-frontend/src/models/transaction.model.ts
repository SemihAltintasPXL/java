export interface Transaction {
  description: string;
  dateTime: string;
  amount: number;
}

