export const environment = {
  backendUrl: 'http://localhost:8081', // Your development backend URL
};
